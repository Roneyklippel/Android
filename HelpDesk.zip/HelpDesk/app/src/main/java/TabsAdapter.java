public class TabsAdapter {
}
